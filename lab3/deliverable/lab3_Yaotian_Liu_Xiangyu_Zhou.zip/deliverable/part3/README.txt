Part 3: CAD Algorithm Evaluation
================================

Prerequisites:
  module load vtr/8.0.0-git
  source activate vtr

Files:
  run_placement.py   - Placement studies #1-#3 (cost vs temp, init_t sweep, normal vs greedy)
  run_routing.py     - Routing studies #1-#3 (max_criticality, param exploration, no A*)
  parse_results.py   - Parses all VPR logs for placement and routing studies, generates CSVs

How to reproduce:

1. Prepare benchmark BLIFs:
   cp /packages/apps/vtr/8.0.0-git/vtr_flow/benchmarks/blif/6/{alu4,ex4p}.blif .

   For diffeq1 and sha, synthesize from Verilog:
   VTR_ROOT=/packages/apps/vtr/8.0.0-git
   mkdir -p synth_diffeq1 && cd synth_diffeq1
   python $VTR_ROOT/vtr_flow/scripts/run_vtr_flow.py \
     $VTR_ROOT/vtr_flow/benchmarks/verilog/diffeq1.v \
     $VTR_ROOT/vtr_flow/arch/timing/k6_frac_N10_mem32K_40nm.xml -end abc
   cp temp/diffeq1.abc.blif ../diffeq1.blif && cd ..
   (Repeat similarly for sha.v)

2. Run placement studies (via SLURM):
   python run_placement.py --slurm --study all
   bash results/placement/study1/slurm_jobs/submit_all.sh
   bash results/placement/study2/slurm_jobs/submit_all.sh
   bash results/placement/study3/slurm_jobs/submit_all.sh

3. Run routing studies (via SLURM):
   python run_routing.py --slurm --study all
   bash results/routing/study1/slurm_jobs/submit_all.sh
   bash results/routing/study2/slurm_jobs/submit_all.sh
   bash results/routing/study3/slurm_jobs/submit_all.sh

4. Parse all results:
   python parse_results.py

Output:
  Placement:
    results/placement/study1/{bench}_cost_vs_temp.csv   - Cost vs temperature curves
    results/placement/study2/study2_summary.csv         - Init temperature sweep results
    results/placement/study3/study3_summary.csv         - Normal vs greedy comparison

  Routing:
    results/routing/study1/study1_summary.csv           - max_criticality=0.5 results
    results/routing/study2/study2_summary.csv           - Parameter exploration results
    results/routing/study3/study3_summary.csv           - No A* (astar_fac=0) results
