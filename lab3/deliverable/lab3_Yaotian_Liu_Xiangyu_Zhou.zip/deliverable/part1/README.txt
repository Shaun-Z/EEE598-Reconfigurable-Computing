Part 1: Logic Block Architecture Evaluation
============================================

Prerequisites:
  module load vtr/8.0.0-git
  source activate vtr

Files:
  arch/                     - Architecture XML files (Arch1, Arch2, Arch3)
  task_config/              - VTR task configuration files
  parse_part1.py            - Parsing script to extract CLBs and frequency from VPR logs
  plot_part1.py             - Plotting script to generate comparison charts

How to reproduce:

1. Run VTR task:
   python /packages/apps/vtr/8.0.0-git/vtr_flow/scripts/run_vtr_task.py task_config/

2. Parse results:
   python parse_part1.py

3. Generate plots:
   python plot_part1.py
