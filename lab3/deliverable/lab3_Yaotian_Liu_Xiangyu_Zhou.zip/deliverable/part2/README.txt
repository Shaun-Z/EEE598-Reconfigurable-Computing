Part 2: Routing Architecture Evaluation
=======================================

Prerequisites:
  module load vtr/8.0.0-git
  source activate vtr

Files:
  gen_archs.py       - Generates 6 architecture XML variants from base k6_N10_40nm.xml
                       Experiment 1: L=1, L=4, L=16 (wire length)
                       Experiment 2: Fc=0.15, Fc=0.5, Fc=1.0
  run_part2.py       - Automates VPR runs: min-W binary search + 1.3W low-stress routing
  parse_results.py   - Parses VPR logs, computes arithmetic mean (seeds) and geometric mean (benchmarks)

How to reproduce:

1. Generate architecture XML variants:
   python gen_archs.py

2. Place the 8 benchmark .blif files from the lab zip into ../a4_benchmarks/

3. Run all experiments (via SLURM):
   python run_part2.py --slurm --experiment both --seeds 1 2 3
   bash results/exp1/slurm_jobs/submit_all_exp1.sh
   bash results/exp2/slurm_jobs/submit_all_exp2.sh

   Or run locally (slow):
   python run_part2.py --experiment both --seeds 1 2 3

4. Parse results into CSV:
   python parse_results.py

Output:
  results/exp1/exp1_summary.csv   - Experiment 1 summary with GEOMEAN
  results/exp1/exp1_detailed.csv  - Per-seed detailed results
  results/exp2/exp2_summary.csv   - Experiment 2 summary with GEOMEAN
  results/exp2/exp2_detailed.csv  - Per-seed detailed results
